const wibu = (prefix, pushname) => {
	return ` 

_*Wibu*_
╰─⊱ *${prefix}sarananime*
Usage : ${prefix}sarananime
╰─⊱ *${prefix}kiss*
Usage : ${prefix}kiss
╰─⊱ *${prefix}randomhug*
Usage : ${prefix}randomhug
╰─⊱ *${prefix}randomcry*
Usage : ${prefix}randomcry
╰─⊱ *${prefix}randomanime*
Usage : ${prefix}randomanime
╰─⊱ *${prefix}waifu*
Usage : ${prefix}waifu
╰─⊱ *${prefix}waifu2*
Usage : ${prefix}waifu2
╰─⊱ *${prefix}nakonime*
Usage : ${prefix}nakonime
╰─⊱ *${prefix}nekonime2*
Usage : ${prefix}nekonime2
╰─⊱ *${prefix}wait*
Usage : ${prefix}wait
╰─⊱ *${prefix}wibu*
Usage : ${prefix}wibu
╰─⊱ *${prefix}pokemon*
Usage : ${prefix}pokemon
`
}
exports.wibu = wibu