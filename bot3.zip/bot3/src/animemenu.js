const animemenu = (prefix) => { 
	return `
✎═─⊱〘 𝐴𝑁𝐼𝑀𝐸 𝑀𝐸𝑁𝑈 〙⊰══
║
╰─⊱ *${prefix}randomanime*
Usage : ${prefix}randomanime
╰─⊱ *${prefix}animerandom*
Usage : ${prefix}animerandom
╰─⊱ *${prefix}ranime*
Usage : ${prefix}ranime
╰─⊱ *${prefix}waifu*
Usage : ${prefix}waifu
╰─⊱ *${prefix}waifu2*
Usage : ${prefix}waifu2
╰─⊱ *${prefix}waifu3*
Usage : ${prefix}waifu3
╰─⊱ *${prefix}nekonime*
Usage : ${prefix}nekonime
╰─⊱ *${prefix}wait*
Usage : ${prefix}wait
╰─⊱ *${prefix}pokemon*
Usage : ${prefix}pokemon
║
✎═─⊱〘 BOT INDapk © 2021 〙⊰══`
}
exports.animemenu = animemenu