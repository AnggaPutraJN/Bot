const aplikasimod = (prefix) => { 
	return `
╔══✪〘 APK MOD 〙✪════════════
║
╠➥ *${prefix}emulator*
Usage : ${prefix}emulator
╠➥ *${prefix}aplikasi*
Usage : ${prefix}aplikasi
╠═══════════════════════════
〘  BOT INDapk 〙

	`
}
exports.aplikasimod = aplikasimod