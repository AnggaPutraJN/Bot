const animemenu = (prefix) => { 
	return `
✎═─⊱〘 𝐴𝑁𝐼𝑀𝐸 𝑀𝐸𝑁𝑈 〙⊰══
║
╰─⊱ *${prefix}randomanime*
╰─⊱ *${prefix}animerandom*
╰─⊱ *${prefix}ranime*
╰─⊱ *${prefix}waifu*
╰─⊱ *${prefix}waifu2*
╰─⊱ *${prefix}waifu3*
╰─⊱ *${prefix}nekonime*
╰─⊱ *${prefix}wait*
╰─⊱ *${prefix}pokemon*
║
✎═─⊱〘 BOT INDapk 𝑀𝐸𝑁𝑈 〙⊰══`
}
exports.animemenu = animemenu