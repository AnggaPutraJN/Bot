const help = (prefix) => { 
	return `
╔══✪〘 BUY VIP 〙✪═══════════
║➤${prefix}buyvip
║➤Deskripsi :gunakan command diatas untuk beli Full Akses Bot
╠════════════════════════════
▣═─⊱【 𝐿𝐼𝑆𝑇 𝑀𝐸𝑁𝑈 】⊰─══
║
╰─⊱ *${prefix}help*
Usage : ${prefix}help
╰─⊱ *${prefix}vipmenu*
Usage : ${prefix}vipmenu
╰─⊱ *${prefix}adminmenu*
Usage : ${prefix}adminmenu
╰─⊱ *${prefix}gamingmenu*
Usage : ${prefix}gamingmenu
╰─⊱ *${prefix}nsfwmenu*
Usage : ${prefix}nsfwmenu
╰─⊱ *${prefix}animemenu*
Usage : ${prefix}animemenu
╰─⊱ *${prefix}othermenu*
Usage : ${prefix}othermenu
╰─⊱ *${prefix}makermenu*
Usage : ${prefix}makermenu
╰─⊱ *${prefix}mediamenu*
Usage : ${prefix}mediamenu
╰─⊱ *${prefix}funmenu*
Usage : ${prefix}funmenu
╰─⊱ *${prefix}kerangmenu*
Usage : ${prefix}kerangmenu
╰─⊱*${prefix}listmenu*
Usage : *${prefix}listmenu [Menunya Lebih Lengkap!]
║
║
║
▣═─⊱【 TIPS 】⊰─══
Ketik *${prefix}kegunaanbot* untuk melihat list informasi tentang  BOT
Ketik *${prefix}owner* untuk melihat kontak owner
Mau donasi? 082286344446(Gopay)
➤Report Bug : *${prefix}reportbug*
╰─⊱ *${prefix}kegunaanbot*
Usage : *${prefix}kegunaanbot
╰─⊱ *${prefix}rules*
Usage : *${prefix}rules

Jika tidak ingin donasi bantu Follow Ig Dan Fanspage aja kak 
_instagram.com/indapk_
_facebook.com/indapk_
║
▣══─⊱ 【 𝑅𝑈𝑁𝑇𝐼𝑀𝐸 】 ⊰─══
║
╰─⊱ *STATUS BOT: Online*
╭─⊱ BOT ON: *24JAM*
║
▣══─ ⸨ BOT INDapk © 2021 ⸩ ─══▣`
}
exports.help = help
