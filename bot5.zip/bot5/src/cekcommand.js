const cekcommand = (prefix) => { 
	return `
╔══✪〘 COMMAND 〙✪══
║ PREFIX YANG SAAT INI DIGUNAKAN 「* ${prefix} *」
╚══✪〘 BOT INDapk © 2021 〙✪══
`
}
exports.cekcommand = cekcommand