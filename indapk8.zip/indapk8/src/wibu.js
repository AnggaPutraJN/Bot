const wibu = (prefix, pushname) => {
	return ` 

_*Wibu*_
╰─⊱ *${prefix}sarananime*
╰─⊱ *${prefix}kiss*
╰─⊱ *${prefix}peluk*
╰─⊱ *${prefix}randomcry*
╰─⊱ *${prefix}randomanime*
╰─⊱ *${prefix}waifu*
╰─⊱ *${prefix}waifu2*
╰─⊱ *${prefix}nakonime*
╰─⊱ *${prefix}nekonime2*
╰─⊱ *${prefix}wait*
╰─⊱ *${prefix}wibu*
╰─⊱ *${prefix}pokemon*
`
}
exports.wibu = wibu