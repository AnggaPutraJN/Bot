const kegunaanbot = () => { 
	return ` *👾INFO BOT👾*

╔══✪〘 TIPS & Peraturan 〙✪════════════
*KEGUNAAN UTAMA* Untuk share informasih mengenai tentang game
╠═══════════════════════════
╠➥ Untuk menggunakan bot ini, harus daftar dulu sebagai user, dengan cara ketik command ${prefix}daftar Nama kamu | Umur kamu
╠➥ Jangan terlalu sering mengunakan bot (Spam bot), gunakan sewajarnya aja
╠➥ Jangan merespon bot saat melakukan broadcast atau promosikan game
╠➥ Laporkan ke owner bot jika ada error dengan cara ketik command ${prefix}owner
╠➥ Support Bot dengan cara ketik command ${prefix}donate
╠═══════════════════════════
〘  BOT INDapk 〙
`
}
exports.kegunaanbot = kegunaanbot
