const listmenu = (prefix) => { 
	return `                 
╔══✪〘 VIP OWNER 〙✪═══════════
║
╰─⊱  *${prefix}leave*
Usage : ${prefix}leave [Untuk mengeluarkan bot]
╰─⊱  *${prefix}setprefix*
Usage : ${prefix}setprefix . atau !
[Command yg dapat digunakan ${prefix}setcommand, ${prefix}setprefix]
╰─⊱  *${prefix}unban*
Usage : ${prefix}unban Tag namanya
╰─⊱  *${prefix}ban*
Usage : ${prefix}ban Tag namanya
╰─⊱  *${prefix}hidetag50*
Usage : ${prefix}hidetag50 [Command yg dapat digunakan : ${prefix}hidetag50, ${prefix}spam50]
╰─⊱ *${prefix}addadmin*
Usage : ${prefix}addadmin Tag orangnya [Fitur ini masih error]
║
╠══✪〘 ALL MENU 〙✪═══════════
║
╰─⊱ *${prefix}help*
Usage : ${prefix}help
╰─⊱ *${prefix}menuowner*
Usage : ${prefix}menuowner
╰─⊱ *${prefix}adminmenu*
Usage : ${prefix}adminmenu
╰─⊱ *${prefix}gamingmenu*
Usage : ${prefix}gamingmenu
╰─⊱ *${prefix}nsfwmenu*
Usage : ${prefix}nsfwmenu
╰─⊱ *${prefix}animemenu*
Usage : ${prefix}animemenu
╰─⊱ *${prefix}othermenu*
Usage : ${prefix}othermenu
╰─⊱ *${prefix}makermenu*
Usage : ${prefix}makermenu
╰─⊱ *${prefix}mediamenu*
Usage : ${prefix}mediamenu
╰─⊱ *${prefix}funmenu*
Usage : ${prefix}funmenu
╰─⊱ *${prefix}kerangmenu*
Usage : ${prefix}kerangmenu
║
╠══✪〘 ADMIN 〙✪═══════════
║
╰─⊱  *${prefix}clone*
Usage : ${prefix}clone Tag target yang ingin di clone [Command yg dapat di gunakan : ${prefix}setppbot, ${prefix}clone]
╰─⊱ *${prefix}snk*
Usage : ${prefix}snk
╰─⊱ *${prefix}tagall*
Usage : ${prefix}tagall
╰─⊱  *${prefix}otagall*
Usage : ${prefix}otagall
╰─⊱  *${prefix}setdesc*
Usage : ${prefix}setdesc Masukkan Teksnya Untuk mengubah deskripsi grup
╰─⊱  *${prefix}setname*
Usage : ${prefix}setname Masukkan Teksnya Untuk mengubah nama grup
╰─⊱  *${prefix}kick* [tag]
Usage : ${prefix}kick Tag Member yang ingin di kick
╰─⊱  *${prefix}add* [628xxx]
Usage : ${prefix}add 628xxx Masukin nomor target
[Command yg dapat digunakan : ${prefix}summon, ${prefix}kuchiyose]
╰─⊱  *${prefix}promote* [tag]
Usage : ${prefix}promote Tag member untuk dijadikan admin
╰─⊱  *${prefix}demote* [tag]
Usage : ${prefix}demote Tag admin untuk tidak dijadikan admin lagi
╰─⊱  *${prefix}group* [buka]
Usage : ${prefix}group buka
╰─⊱  *${prefix}group* [tutup]
Usage : ${prefix}group tutup
╰─⊱  *${prefix}setpp*
Usage : ${prefix}setpp Upload gambar yg ingin dijadikan icon group!
╰─⊱  *${prefix}nsfw* [1/0]
Usage : ${prefix}nsfw 1 untuk mengaktifkan fitur nsfw dan ${prefix}nsfw 0 untuk nonaktifkan fitur
╰─⊱  *${prefix}anime* [1/0]
Usage : ${prefix}anime 1 untuk mengaktifkan fitur anime dan ${prefix}anime 0 untuk nonaktifkan fitur
╰─⊱  *${prefix}simih* [1/0]
Usage : ${prefix}simih 1 untuk mengaktifkan fitur simih dan ${prefix}simih 0 untuk nonaktifkan fitur
╰─⊱  *${prefix}welcome* [1/0]
Usage : ${prefix}welcome 1 Untuk mengaktifkan welcome pada grup dan ${prefix}welcome 0 untuk menonaktifkan
[Command yg dapat digunakan : ${prefix}welcome [1/0], ${prefix}welkam [1/0]]
╰─⊱  *${prefix}listadmin*
Usage : ${prefix}listadmin
[Command yg dapat di gunakan : ${prefix}listadmin, ${prefix}adminlist]
╰─⊱  *${prefix}hidetag5*
Usage : ${prefix}hidetag5
[Command yg dapat digunakan : ${prefix}hidetag5, ${prefix}spam5]
╰─⊱  *${prefix}hidetag20*
Usage : ${prefix}hidetag20
[Command yg dapat digunakan : ${prefix}hidetag20, ${prefix}spam20]
╰─⊱  *${prefix}hidetag*
Usage : ${prefix}hidetag
[Command yg dapat digunakan : ${prefix}hidetag, ${prefix}spam]
╰─⊱ *${prefix}turnoff*
Usage : ${prefix}turnoff Untuk mematikan bot
[Command yg dapat digunakan ${prefix}turnoff,${prefix}turnoffbot, ${prefix}botoff]
║
╠══✪〘 Gaming Menu 〙✪═══ *[NEW Fitur]*
║
╰─⊱ *${prefix}gamingmenu*
Usage : ${prefix}gamingmenu
╰─⊱ *${prefix}aplikasimod*
Usage : ${prefix}aplikasimod
║
╠══✪〘 FUN 〙✪═══════════
║
╰─⊱ *${prefix}vn [kode bhs] [teks]*
Usage : ${prefix}vn id Owner ganteng [Kode bahasa untuk bahasa Indonesia, Ketik ${prefix}kodebhs untuk cek kode-kode bahasanya]
╰─⊱ *${prefix}kodebhs*
Usage : ${prefix}kodebhs
╰─⊱ *${prefix}truth*
Usage : ${prefix}truth
╰─⊱ *${prefix}dare*
Usage : ${prefix}dare
╰─⊱ *${prefix}pinterest*
Usage : ${prefix}pinterest naruto (masukin aja text bebas)
╰─⊱ *${prefix}syg* [text]
Usage : ${prefix}syg aku ganteng gak [Masukkan text atau pertanyaan]
║
╠══✪〘 KERANG 〙✪═════════
║
╰─⊱ *${prefix}apakah [optional]*
Usage : ${prefix}apakah Masukkan textnya bebas
╰─⊱ *${prefix}rate [optional]*
Usage : ${prefix}rate Masukkan textnya bebas
╰─⊱ *${prefix}bisakah [optional]*
Usage : ${prefix}bisakah Masukkan textnya bebas
╰─⊱ *${prefix}kapankah [optional]*
Usage : ${prefix}kapankah Masukkan textnya bebas
╰─⊱ *${prefix}gantengcek*
Usage : ${prefix}
╰─⊱ *${prefix}toxic*
Usage : ${prefix}toxic
╰─⊱ *${prefix}cantikcek*
Usage : ${prefix}cantikcek
╰─⊱ *${prefix}gay [tag]*
Usage : ${prefix}gay Tag orangnya
║
╠══✪〘 MAKER 〙✪═══════════*[NEW Fitur]*
║
╰─⊱ *${prefix}lava* [text]
Usage : ${prefix}lava AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}firework* [text]
Usage : ${prefix}firework AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}blood* [text]
Usage : ${prefix}blood AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}sumery* [text]
Usage : ${prefix}sumery AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}toxic2* [text]
Usage : ${prefix}toxic2 AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}neontext* [text]
Usage : ${prefix}neontext AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}grenneon* [text]
Usage : ${prefix}grenneon AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}dropwater* [text]
Usage : ${prefix}dropwater AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}metaldark* [text]
Usage : ${prefix}metaldark AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}sandwrite* [text]
Usage : ${prefix}sandwrite AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}summer* [text]
Usage : ${prefix}summer AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}shadow* [text]
Usage : ${prefix}shadow AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
║
╠══✪〘 MEDIA 〙✪═══════════
║
╰─⊱ *${prefix}ytkomen* [Nama|Teksnya]
Usage : ${prefix}ytkomen Masukkan nama kalian | Komentar atau Text bebas
╰─⊱ *${prefix}lirik* [judul lagu]
Usage : ${prefix}lirik Impossible
╰─⊱ *${prefix}chord* [judul lagu]
Usage : ${prefix}chord Impossible
╰─⊱ *${prefix}url2img* [link]
Usage : ${prefix}url2img Mobile | Linknya [Tipenya ada Desktop, Tablet, Mobile]
╰─⊱ *${prefix}fototiktok* [username]
Usage : ${prefix}fototiktok anggaputrajn [Masukkan id usernamenya]
╰─⊱ *${prefix}map* [kota]
Usage : ${prefix}map Makassar [Masukkan nama kotanya]
╰─⊱ *${prefix}kbbi* [kamus]
Usage : ${prefix}kbbi Masukkan kamusnya
╰─⊱ *${prefix}infocuaca* [kota]
Usage : ${prefix}infocuaca Makassar [Masukkan nama kotanya]
╰─⊱ *${prefix}artinama [nama]*
Usage : ${prefix}artinama anggaputrajn [Masukkan nama]
╰─⊱ *${prefix}resepmasakan [optional]*
Usage : ${prefix}resepmasakan ayam goreng [Bebas]
╰─⊱ *${prefix}tiktokstalk [@username]*
Usage : ${prefix}tiktokstalk anggaputrajn [Masukkan id usernamenya]
╰─⊱ *${prefix}wiki [query]*
Usage : ${prefix}wiki [Masukkan querynya]
╰─⊱ *${prefix}qrcode [optional]*
Usage : ${prefix}qrcode indapk.com [bebas mau diisi apa, diisi link juga boleh]
╰─⊱ *${prefix}ssweb [linkWeb]*
Usage : ${prefix}ssweb https://www.indapk.com
║
╠══✪〘 NSFW 〙✪═══════════
║
╰─⊱ *${prefix}randomhentai* [Fitur khusus Admin]
Usage : ${prefix}randomhentai
╰─⊱ *${prefix}hentai*
Usage : ${prefix}hentai
╰─⊱ *${prefix}blowjob* [Fitur khusus Admin]
Usage : ${prefix}blowjob
[Command yg dapat digunakan : ${prefix}nsfwblowjob, ${prefix}blowjob]
╰─⊱ *${prefix}nsfwtrap* [Fitur khusus Admin]
Usage : ${prefix}nsfwtrap
╰─⊱ *${prefix}kodenuklir2*
Usage : ${prefix}kodenuklir2
╰─⊱ *${prefix}kodenuklir*
Usage : ${prefix}kodenuklir
╰─⊱ *${prefix}nekopoi*
Usage : ${prefix}nekopoi
╰─⊱  *${prefix}indo(1-25)* [Fitur khusus Admin]
Usage : ${prefix}indo23 [Masukkan angkanya 1 sampai 25]
║
╠══✪〘 OTHER 〙✪═══════════
║
╰─⊱ *${prefix}s [replay gambar]*
Usage : ${prefix}s Replay gambar atau masukin gambar
╰─⊱ *${prefix}toimg [replay sticker]*
Usage : ${prefix}toimg Replay Stickernya
╰─⊱  *${prefix}tagme*
Usage : ${prefix}tagme
╰─⊱  *${prefix}groupinfo*
Usage : ${prefix}groupinfo
╰─⊱  *${prefix}infogc*
Usage : ${prefix}infogc
╰─⊱  *${prefix}linkgc*
Usage : ${prefix}linkgc
╰─⊱ *${prefix}dadu*
Usage : ${prefix}dadu
╰─⊱ *${prefix}ocr [gambar]*
Usage : ${prefix}ocr [Masukin gambarnya]
╰─⊱ *${prefix}meme*
Usage : ${prefix}meme
╰─⊱ *${prefix}testime*
Usage : ${prefix}testime
╰─⊱ *${prefix}hobby*
Usage : ${prefix}hobby Masukkan teksnya
╰─⊱ *${prefix}slap*
Usage : ${prefix}slap
╰─⊱ *${prefix}beritahoax*
Usage : ${prefix}beritahoax
╰─⊱ *${prefix}watak*
Usage : ${prefix}watak
╰─⊱ *${prefix}artinama* [nama]
Usage : ${prefix}artinama anggaputrajn [Masukin nama]
╰─⊱ *${prefix}listsurah*
Usage : ${prefix}listsurah
╰─⊱ *${prefix}fitnah [@tag|pesan|balasanbot]*
Usage : ${prefix}fitnah Tag|Pesannya|Balasan botnya
╰─⊱ *${prefix}premiumlist*
Usage : ${prefix}premiumlist
╰─⊱ *${prefix}tentangindapk*
Usage : ${prefix}tentangindapk
╰─⊱ *${prefix}iklan*
Usage : ${prefix}iklan
╰─⊱ *${prefix}runtime*
Usage : ${prefix}runtime
╰─⊱ *${prefix}infonomor*
Usage : ${prefix}infonomor 082286344446 [Masukkan nomornya]
╰─⊱ *${prefix}wame*
Usage : ${prefix}wame
╰─⊱ *${prefix}snk*
Usage : ${prefix}snk
║
╠═══✪〘 ANIME 〙✪═══════════
║
╰─⊱ *${prefix}animesaran*
Usage : ${prefix}animesaran
╰─⊱ *${prefix}cry*
Usage : ${prefix}cry
╰─⊱ *${prefix}kiss*
Usage : ${prefix}kiss
╰─⊱ *${prefix}randomhug*
Usage : ${prefix}randomhug
╰─⊱ *${prefix}randomanime*
Usage : ${prefix}randomanime
╰─⊱ *${prefix}animerandom*
Usage : ${prefix}animerandom
╰─⊱ *${prefix}ranime*
Usage : ${prefix}ranime
╰─⊱ *${prefix}waifu*
Usage : ${prefix}waifu
╰─⊱ *${prefix}waifu2*
Usage : ${prefix}waifu2
╰─⊱ *${prefix}waifu3*
Usage : ${prefix}waifu3
╰─⊱ *${prefix}nekonime*
Usage : ${prefix}nekonime
[Command yg dapat digunakan : ${prefix}nekonime, ${prefix}randomnekonime]
╰─⊱ *${prefix}scan* [upload gambar]
Usage : ${prefix}scan upload gambar screenshot anime yg ingin di scan [Pastikan gambar screenshotnya jelas ya!]
╰─⊱ *${prefix}pokemon*
Usage : ${prefix}pokemon
║
╠═══✪〘 ANIMALS 〙✪═══════════
║
╰─⊱ *${prefix}anjing*
Usage : ${prefix}anjing
║
╠═════✪
║Ketik *${prefix}kegunaanbot* untuk melihat list informasi tentang indapk bot
║Ketik *${prefix}owner* untuk melihat kontak owner
║Mau donasi? 082286344446(Gopay)
║Jika tidak ingin donasi bantu Follow Ig Dan Fanspage aja kak 
║_instagram.com/indapk
║_facebook.com/indapk
║
✎═─⊱〘 BOT INDapk © 2021 〙⊰══`
}
exports.listmenu = listmenu