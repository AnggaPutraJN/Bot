const listmenu = (prefix) => { 
	return `                 

╔══✪〘 OWNER 〙✪══
║
╰─⊱ *${prefix}block 62858xxxxx*
╰─⊱ *${prefix}unblock 62858xxxxx*
╰─⊱ *${prefix}promote @tagmember*
╰─⊱ *${prefix}demote @tagadmin*
╰─⊱ *${prefix}leave*
╰─⊱  *${prefix}leave*
╰─⊱  *${prefix}clearall*
╰─⊱  *${prefix}clone*
╰─⊱  *${prefix}hidetag*
╰─⊱  *${prefix}hidetag2*
╰─⊱  *${prefix}setprefix*
╰─⊱  *${prefix}unban*
╰─⊱  *${prefix}ban*
╰─⊱ *${prefix}runtime*
╰─⊱ *${prefix}iklan*
╰─⊱ *${prefix}turnoff*
║
╠══✪〘 ADMIN 〙✪══
║
╰─⊱ *${prefix}premiumlist*
╰─⊱ *${prefix}tentangindapk*
╰─⊱ *${prefix}snk*
╰─⊱ *${prefix}ban @tagmember*
╰─⊱ *${prefix}unban @tagmember*
╰─⊱ *${prefix}spamcall [81273xxxx]*
╰─⊱ *${prefix}kickall*
╰─⊱ *${prefix}leave*
╰─⊱ *${prefix}delete*
╰─⊱ *${prefix}tagall*
╰─⊱  *${prefix}otagall*
╰─⊱  *${prefix}otagall2*
╰─⊱  *${prefix}setdesc*
╰─⊱  *${prefix}setname*
╰─⊱  *${prefix}kick* [tag]
╰─⊱  *${prefix}add* [628xxx]
╰─⊱  *${prefix}promote* [tag]
╰─⊱  *${prefix}demote* [tag]
╰─⊱  *${prefix}group* [buka]
╰─⊱  *${prefix}group* [tutup]
╰─⊱  *${prefix}linkgc*
╰─⊱  *${prefix}setpp* [foto kau]
╰─⊱  *${prefix}infogc*
╰─⊱  *${prefix}groupinfo*
╰─⊱  *${prefix}tagme*
╰─⊱  *${prefix}nsfw* [1/0]
╰─⊱  *${prefix}anime* [1/0]
╰─⊱  *${prefix}simih* [1/0]
╰─⊱  *${prefix}welcome* [1/0]
╰─⊱  *${prefix}edotensei*
╰─⊱  *${prefix}listadmins*
╰─⊱  *${prefix}ping*
╰─⊱ *${prefix}iklan*
║
╠══✪〘 FUN 〙✪══ [Maintenance!!]*
║
╰─⊱ *${prefix}truth*
╰─⊱ *${prefix}dare*
╰─⊱ *${prefix}simi* [text]
╰─⊱ *${prefix}gtts* [text]
╰─⊱ *${prefix}tts*
║
╠══✪〘 KERANG 〙✪══
║
╰─⊱ *${prefix}apakah [optional]*
╰─⊱ *${prefix}rate [optional]*
╰─⊱ *${prefix}bisakah [optional]*
╰─⊱ *${prefix}kapankah [optional]*
╰─⊱ *${prefix}gantengcek*
╰─⊱ *${prefix}toxic*
╰─⊱ *${prefix}cantikcek*
╰─⊱ *${prefix}gay [tag]*
║
╠══✪〘 MAKER 〙✪══ *[Maintenance!!]*
║
╰─⊱ *${prefix}shadow* [text]
║
╠══✪〘 MEDIA 〙✪══
║
╰─⊱ *${prefix}yt* [link]
╰─⊱ *${prefix}lirik* [judul lagu]
╰─⊱ *${prefix}chord* [judul lagu]
╰─⊱ *${prefix}tiktokstalk* [username]
╰─⊱ *${prefix}url2img* [link]
╰─⊱ *${prefix}fototiktok* [username]
╰─⊱ *${prefix}map* [kota]
╰─⊱ *${prefix}kbbi* [kamus]
╰─⊱ *${prefix}infocuaca* [kota]
╰─⊱ *${prefix}artinama [nama]*
╰─⊱ *${prefix}resepmasakan [optional]*
╰─⊱ *${prefix}tts [kode bhs] [teks]*
╰─⊱ *${prefix}tiktokstalk [@username]*
╰─⊱ *${prefix}wiki [query]*
╰─⊱ *${prefix}qrcode [optional]*
╰─⊱ *${prefix}ssweb [linkWeb]*
╰─⊱ *${prefix}animesaran*
║
╠══✪〘 VIP USER 〙✪══
║
╰─⊱ *${prefix}ytmp3 [link]*
╰─⊱ *${prefix}hidetag2*
╰─⊱ *${prefix}joox [lagu]*
╰─⊱ *${prefix}setprefix*
╰─⊱ *${prefix}tomp3 [replay video]*
╰─⊱  *${prefix}randomanime*
╰─⊱  *${prefix}randomhentai*
╰─⊱  *${prefix}nsfwloli*
╰─⊱  *${prefix}nsfwblowjob*
╰─⊱  *${prefix}nsfwneko*
╰─⊱  *${prefix}nsfwtrap*
╰─⊱  *${prefix}indohot*
╰─⊱  *${prefix}otagall2*
╰─⊱  *${prefix}otagall3*
╰─⊱  *${prefix}hidetag5*
╰─⊱  *${prefix}indo(1-25)*
╰─⊱  *CONTOH ${prefix}indo1*
║
╠══✪〘 NSFW 〙✪══
║
╰─⊱ *${prefix}randomhentai*
╰─⊱ *${prefix}hentai*
╰─⊱ *${prefix}nsfwblowjob*
╰─⊱ *${prefix}nsfwtrap*
╰─⊱ *${prefix}kodenuklir2*
╰─⊱ *${prefix}randomanime*
╰─⊱ *${prefix}cry*
╰─⊱ *${prefix}kiss*
╰─⊱ *${prefix}randomhug*
╰─⊱ *${prefix}nekonime*
╰─⊱ *${prefix}waifu*
╰─⊱ *${prefix}waifu2*
╰─⊱ *${prefix}kodenuklir*
╰─⊱ *${prefix}nekopoi*
║
╠══✪〘 OTHER 〙✪══
║
╰─⊱ *${prefix}s [[replay gambar]*
╰─⊱ *${prefix}sticker [replay gambar]*
╰─⊱ *${prefix}stiker [replay gambar]*
╰─⊱ *${prefix}ttp [teks]*
╰─⊱ *${prefix}toimg [replay sticker]*
╰─⊱ *${prefix}pokemon*
╰─⊱ *${prefix}dadu*
╰─⊱ *${prefix}ocr [gambar]*
╰─⊱ *${prefix}meme*
╰─⊱ *${prefix}testime*
╰─⊱ *${prefix}ttp [teks]*
╰─⊱ *${prefix}hobby*
╰─⊱ *${prefix}slap*
╰─⊱ *${prefix}beritahoax*
╰─⊱ *${prefix}watak*
╰─⊱ *${prefix}jsholat [daerah]*
╰─⊱ *${prefix}report*
╰─⊱ *${prefix}cekjodoh* [nama]
╰─⊱ *${prefix}artinama* [indapk]
╰─⊱ *${prefix}listsurah*
╰─⊱ *${prefix}fitnah [@tag|pesan|balasanbot]]*
║
╠═══✪〘 ANIME 〙✪══
║
╰─⊱ *${prefix}randomanime*
╰─⊱ *${prefix}animerandom*
╰─⊱ *${prefix}ranime*
╰─⊱ *${prefix}waifu*
╰─⊱ *${prefix}waifu2*
╰─⊱ *${prefix}waifu3*
╰─⊱ *${prefix}nekonime*
╰─⊱ *${prefix}wait*
╰─⊱ *${prefix}pokemon*
║
╠═══✪〘 ANIMALS 〙✪══
║
╰─⊱ *${prefix}anjing*
║
╚════✪ Ketik *${prefix}kegunaanbot* untuk melihat list informasi tentang indapk bot
       Ketik *${prefix}owner* untuk melihat kontak owner
         Mau donasi? 082286344446(Gopay)
         Jika tidak ingin donasi bantu Follow Ig Dan Fanspage aja kak 
         _instagram.com/indapk
		 _facebook.com/indapk
    _* BOT INDapk © 2021*_`
}
exports.listmenu = listmenu