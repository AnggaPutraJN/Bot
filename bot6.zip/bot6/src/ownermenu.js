const ownermenu = (prefix) => { 
	return `
	
╔══✪〘 OWNER 〙✪══
║
╰─⊱  *${prefix}leave*
Usage : ${prefix}leave [Untuk mengeluarkan bot]
╰─⊱  *${prefix}setprefix*
Usage : ${prefix}setprefix . atau !
[Command yg dapat digunakan ${prefix}setcommand, ${prefix}setprefix]
╰─⊱  *${prefix}unban*
Usage : ${prefix}unban Tag namanya
╰─⊱  *${prefix}ban*
Usage : ${prefix}ban Tag namanya
╰─⊱  *${prefix}hidetag50*
Usage : ${prefix}hidetag50 [Command yg dapat digunakan : ${prefix}hidetag50, ${prefix}spam50]
╰─⊱ *${prefix}addadmin*
Usage : ${prefix}addadmin Tag orangnya [Fitur ini masih error]
║
╚═〘 BOT INDapk © 2021 〙`
}
exports.ownermenu = ownermenu