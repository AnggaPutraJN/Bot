const iklan = () => { 
	return `           
╔══✪〘 IKLAN 〙✪════════════
╠Yang ingin memasang iklan di BOT INDapk atau memasang iklan di situs https://indapk.com , bisa hubungi owner bot ini, dengan ketik ${prefix}owner
╚═〘  BOT INDapk 〙
`
}
exports.iklan = iklan