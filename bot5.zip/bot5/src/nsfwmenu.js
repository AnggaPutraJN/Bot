const nsfwmenu = (prefix) => { 
	return `
╔══✪〘 NSFW 〙✪══
║
║
╰─⊱ *${prefix}randomhentai* [Fitur khusus Admin]
Usage : ${prefix}randomhentai
╰─⊱ *${prefix}hentai*
Usage : ${prefix}hentai
╰─⊱ *${prefix}blowjob* [Fitur khusus Admin]
Usage : ${prefix}blowjob
[Command yg dapat digunakan : ${prefix}nsfwblowjob, ${prefix}blowjob]
╰─⊱ *${prefix}nsfwtrap* [Fitur khusus Admin]
Usage : ${prefix}nsfwtrap
╰─⊱ *${prefix}kodenuklir2*
Usage : ${prefix}kodenuklir2
╰─⊱ *${prefix}kodenuklir*
Usage : ${prefix}kodenuklir
╰─⊱ *${prefix}nekopoi*
Usage : ${prefix}nekopoi
╰─⊱  *${prefix}indo(1-25)* [Fitur khusus Admin]
Usage : ${prefix}indo23 [Masukkan angkanya 1 sampai 25]
║
╚═〘 BOT INDapk © 2021 〙`
}
exports.nsfwmenu = nsfwmenu