const help = (prefix) => { 
	return `
❦═─⊱〘 𝐼𝑁𝐹𝑂 〙⊰══
║
╰─⊱ BOT By INDapk
Command untuk chat ownernya : *${prefix}pesankeowner [Pesan kamu!*
║
▣═─⊱【 𝐿𝐼𝑆𝑇 𝑀𝐸𝑁𝑈 】⊰─══
║
╰─⊱ *${prefix}help*
Usage : ${prefix}help
╰─⊱ *${prefix}menuowner*
Usage : ${prefix}menuowner
╰─⊱ *${prefix}adminmenu*
Usage : ${prefix}adminmenu
╰─⊱ *${prefix}gamingmenu*
Usage : ${prefix}gamingmenu
╰─⊱ *${prefix}nsfwmenu*
Usage : ${prefix}nsfwmenu
╰─⊱ *${prefix}animemenu*
Usage : ${prefix}animemenu
╰─⊱ *${prefix}othermenu*
Usage : ${prefix}othermenu
╰─⊱ *${prefix}makermenu*
Usage : ${prefix}makermenu
╰─⊱ *${prefix}mediamenu*
Usage : ${prefix}mediamenu
╰─⊱ *${prefix}funmenu*
Usage : ${prefix}funmenu
╰─⊱ *${prefix}kerangmenu*
Usage : ${prefix}kerangmenu
╰─⊱*${prefix}listmenu*
Usage : *${prefix}listmenu [Menunya Lebih Lengkap!]
║
▣═─⊱【 TIPS 】⊰─══
║
╰─⊱ *${prefix}kegunaanbot*
Usage : *${prefix}kegunaanbot
╰─⊱ *${prefix}rules*
Usage : *${prefix}rules
╰─⊱Command untuk chat owner : *${prefix}pesankeowner [Pesan kamu!*
║
▣══─⊱ 【 𝑅𝑈𝑁𝑇𝐼𝑀𝐸 】 ⊰─══
║
╰─⊱ *STATUS BOT: Online*
▣═─⊱Command untuk chat owner : *${prefix}pesankeowner [Pesan kamu!* ⊰─══
╭─⊱ BOT ON: *24JAM* [Selamat owner ingin mengaktifkan]
║
▣══─ ⸨ BOT INDapk © 2021 ⸩ ─══▣`
}
exports.help = help
