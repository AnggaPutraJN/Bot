const adminmenu = (prefix) => { 
	return `
✎═─⊱〘 𝐴𝐷𝑀𝐼𝑁 𝑀𝐸𝑁𝑈 〙⊰══
║
║
║
║
╰─⊱  *${prefix}clone*
Usage : ${prefix}clone Tag target yang ingin di clone [Command yg dapat di gunakan : ${prefix}setppbot, ${prefix}clone]
╰─⊱ *${prefix}snk*
Usage : ${prefix}snk
╰─⊱ *${prefix}tagall*
Usage : ${prefix}tagall
╰─⊱  *${prefix}otagall*
Usage : ${prefix}otagall
╰─⊱  *${prefix}setdesc*
Usage : ${prefix}setdesc Masukkan Teksnya Untuk mengubah deskripsi grup
╰─⊱  *${prefix}setname*
Usage : ${prefix}setname Masukkan Teksnya Untuk mengubah nama grup
╰─⊱  *${prefix}kick* [tag]
Usage : ${prefix}kick Tag Member yang ingin di kick
╰─⊱  *${prefix}add* [628xxx]
Usage : ${prefix}add 628xxx Masukin nomor target
[Command yg dapat digunakan : ${prefix}summon, ${prefix}kuchiyose]
╰─⊱  *${prefix}promote* [tag]
Usage : ${prefix}promote Tag member untuk dijadikan admin
╰─⊱  *${prefix}demote* [tag]
Usage : ${prefix}demote Tag admin untuk tidak dijadikan admin lagi
╰─⊱  *${prefix}group* [buka]
Usage : ${prefix}group buka
╰─⊱  *${prefix}group* [tutup]
Usage : ${prefix}group tutup
╰─⊱  *${prefix}setpp*
Usage : ${prefix}setpp Upload gambar yg ingin dijadikan icon group!
╰─⊱  *${prefix}nsfw* [1/0]
Usage : ${prefix}nsfw 1 untuk mengaktifkan fitur nsfw dan ${prefix}nsfw 0 untuk nonaktifkan fitur
╰─⊱  *${prefix}anime* [1/0]
Usage : ${prefix}anime 1 untuk mengaktifkan fitur anime dan ${prefix}anime 0 untuk nonaktifkan fitur
╰─⊱  *${prefix}simih* [1/0]
Usage : ${prefix}simih 1 untuk mengaktifkan fitur simih dan ${prefix}simih 0 untuk nonaktifkan fitur
╰─⊱  *${prefix}welcome* [1/0]
Usage : ${prefix}welcome 1 Untuk mengaktifkan welcome pada grup dan ${prefix}welcome 0 untuk menonaktifkan
[Command yg dapat digunakan : ${prefix}welcome [1/0], ${prefix}welkam [1/0]]
╰─⊱  *${prefix}listadmin*
Usage : ${prefix}listadmin
[Command yg dapat di gunakan : ${prefix}listadmin, ${prefix}adminlist]
╰─⊱  *${prefix}hidetag5*
Usage : ${prefix}hidetag5
[Command yg dapat digunakan : ${prefix}hidetag5, ${prefix}spam5]
╰─⊱  *${prefix}hidetag20*
Usage : ${prefix}hidetag20
[Command yg dapat digunakan : ${prefix}hidetag20, ${prefix}spam20]
╰─⊱  *${prefix}hidetag*
Usage : ${prefix}hidetag
[Command yg dapat digunakan : ${prefix}hidetag, ${prefix}spam]
╰─⊱ *${prefix}turnoff*
Usage : ${prefix}turnoff Untuk mematikan bot
[Command yg dapat digunakan ${prefix}turnoff,${prefix}turnoffbot, ${prefix}botoff]
║
║
║
║
✎═─⊱〘 BOT INDapk © 2021 〙⊰══`
}
exports.adminmenu = adminmenu