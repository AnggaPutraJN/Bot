const menuvip = (prefix) => { 
	return `
╔══✪〘 VIP MENU 〙✪═══════════
║➤${prefix}buyvip
║➤Deskripsi :gunakan command diatas untuk beli Full Akses Bot
╠════════════════════════════
╰─⊱  *${prefix}bcgc*
Usage : ${prefix}bcgc [Pesan yg ingin dimasukkan]
Deskripsi : Untuk chat kesemua member grup
╰─⊱  *${prefix}scan*
Usage : ${prefix}scan [Upload screesnhot anime yang ingin di scan]
Deskripsi : Untuk scan ss anime, hentai dll, Pastikan gambarnya harus jelas !
╰─⊱  *${prefix}spam50*
Usage : ${prefix}spam50
Deskripsi : Untuk spam grup sebanyak 100
╰─⊱  *${prefix}spam20*
Usage : ${prefix}spam20
Deskripsi : Untuk spam grup sebanyak 20
╰─⊱  *${prefix}spam5*
Usage : ${prefix}spam5
Deskripsi : Untuk spam grup sebanyak 5
╰─⊱  *${prefix}spam2*
Usage : ${prefix}spam2
Deskripsi : Untuk spam grup sebanyak 2
╰─⊱  *${prefix}bannedmember*
Usage : ${prefix}bannedmember Tag namanya
Deskripsi : Untuk banned member dari list bot
╰─⊱  *${prefix}setppbot*
╰─⊱  *${prefix}unban*
Usage : ${prefix}unban Tag nama yg sudah dibanned
Deskripsi : Untuk melepas banned member dari list bot
╰─⊱  *${prefix}setppbot*
Usage : ${prefix}setppbot
Deskripsi : Untuk mengubah foto profile bot
╰─⊱  *${prefix}tagall*
Usage : ${prefix}tagall
Deskripsi : Untuk tag semua member
╰─⊱  *${prefix}tomp3*
Usage : ${prefix}tomp3 [Reply videonya]
Deskripsi : Untuk mengubah Video Ke MP3
╰─⊱  *${prefix}joox*
Usage : ${prefix}joox [Masukkan judul lagunya]
Deskripsi : Untuk Download Musik
╰─⊱  *${prefix}lirik*
Usage : ${prefix}lirik [Masukkan judul lagunya]
Deskripsi : Untuk Cek Lirik Musik
╰─⊱  *${prefix}promote*
Usage : ${prefix}promote [Tag namanya]
Deskripsi : Untuk menjadikan admin grup, Pastikan BOTnya harus admin grup dulu!
╰─⊱  *${prefix}indo1-25*
Usage : ${prefix}indo1-25 (26- ∞ Comingsoon)
Deskripsi : Untuk download bokep [Nanti owner akan menambahkan lagi]
╰─⊱  *${prefix}nsfw*
Usage : ${prefix}nsfw [1/0]
Deskripsi : Untuk mengaktifkan fitur nsfw angka 1 untuk aktifkan, dan angka 0 untuk nonaktif
╰─⊱  *${prefix}hentai*
Usage : ${prefix}hentai
Deskripsi : Random hentai [∞]
╰─⊱  *${prefix}nsfwtrap*
Usage : ${prefix}nsfwtrap
Deskripsi : Random trap [∞]
╰─⊱  *${prefix}blowjob*
Usage : ${prefix}blowjob
Deskripsi : Random blowjob [∞]
╰─⊱  *${prefix}randomhentai*
Usage : ${prefix}randomhentai
Deskripsi : Random hentai 2 [∞]
╰─⊱  *${prefix}nekopoi*
Usage : ${prefix}nekopoi
Deskripsi : Akses Nekopoi Tanpa VPN
╰─⊱ *${prefix}kodebhs*
Usage : ${prefix}kodebhs
Deskripsi : Voice Note Menggunakan Suara Google Translate
║
╚═〘 BOT INDapk © 2021 〙`
}
exports.menuvip = menuvip