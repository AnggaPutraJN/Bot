const donasi = () => {
	return `👾INDapk👾	

  Hi👋️
  
          *FITUR*
          
┏━━━°❀ ❬ 𝘼𝘽𝙊𝙐𝙏 ❭ ❀°━━━┓
┃
┏❉ *#info*
┣❉ *#Donasi* 
┗❉ *#creator* 
┃
┣━━━°❀ ❬ 𝗗𝗢𝗡𝗔𝗦𝗜 ❭ ❀°━━━⊱
┃
┣➥ *GOPAY:* 082286344446
┣➥ *PULSA:* 082286344446
┣➥ *OVO:* 082286344446

┃ 𝗣𝗢𝗪𝗘𝗥𝗘𝗗 𝗕𝗬 INDapk
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.donasi = donasi
