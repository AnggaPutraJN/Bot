const mediamenu = (prefix) => { 
	return `

╔══✪〘 MEDIA 〙✪══
║
╰─⊱ *${prefix}yt* [link]
╰─⊱ *${prefix}lirik* [judul lagu]
╰─⊱ *${prefix}chord* [judul lagu]
╰─⊱ *${prefix}tiktokstalk* [username]
╰─⊱ *${prefix}url2img* [link]
╰─⊱ *${prefix}fototiktok* [username]
╰─⊱ *${prefix}map* [kota]
╰─⊱ *${prefix}kbbi* [kamus]
╰─⊱ *${prefix}infocuaca* [kota]
╰─⊱ *${prefix}artinama [nama]*
╰─⊱ *${prefix}resepmasakan [optional]*
╰─⊱ *${prefix}tts [kode bhs] [teks]*
╰─⊱ *${prefix}tiktokstalk [@username]*
╰─⊱ *${prefix}wiki [query]*
╰─⊱ *${prefix}qrcode [optional]*
╰─⊱ *${prefix}ssweb [linkWeb]*
╰─⊱ *${prefix}animesaran*
║
╚═〘  BOT INDapk 〙`
}
exports.mediamenu = mediamenu