const snk = () => { 
	return `
╔══✪〘 SYARAT DAN KETENTUAN BOT 〙✪════
║➤ Kami tidak menyimpan gambar, video, file, audio, dan dokumen yang anda kirim
║➤ Kami tidak akan pernah meminta anda untuk memberikan informasi pribadi
║➤ Jika menemukan Bug/Error silahkan langsung lapor ke Owner bot
║➤ Apapun yang anda perintah pada bot ini, KAMI TIDAK AKAN BERTANGGUNG JAWAB!
║
╠══✪〘 TIPS 〙✪════
║
║➤Cek Kegunaan atau Fitur pada BOT silakan ketik *${prefix}kegunaanbot*
║➤Cek Rules BOT silakan ketik *${prefix}rules*
║
╠═══✪〘 BUY VIP 〙✪═══════════
║➤${prefix}buyvip
║➤Deskripsi :gunakan command diatas untuk beli Full Akses Bot
╠════════════════════════════
╚═〘 BOT INDapk © 2021`
}
exports.snk = snk
