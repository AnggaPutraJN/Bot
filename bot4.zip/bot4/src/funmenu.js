const funmenu = (prefix) => { 
	return `
✎═─⊱〘 𝐹𝑈𝑁 𝑀𝐸𝑁𝑈 〙⊰══
║
╰─⊱ *${prefix}truth*
Usage : ${prefix}
╰─⊱ *${prefix}dare*
Usage : ${prefix}
╰─⊱ *${prefix}syg*
Usage : ${prefix}syg Lagi ngapain (kata katanya bebas)
╰─⊱ *${prefix}pinterest*
Usage : ${prefix}pinterest naruto (masukin aja text bebas)
║
✎═─⊱〘 BOT INDapk © 2021 〙⊰══`
}
exports.funmenu = funmenu