const animemenu = (prefix) => { 
	return `
✎═─⊱〘 𝐴𝑁𝐼𝑀𝐸 𝑀𝐸𝑁𝑈 〙⊰══
║
╰─⊱ *${prefix}animesaran*
Usage : ${prefix}animesaran
╰─⊱ *${prefix}cry*
Usage : ${prefix}cry
╰─⊱ *${prefix}kiss*
Usage : ${prefix}kiss
╰─⊱ *${prefix}randomhug*
Usage : ${prefix}randomhug
╰─⊱ *${prefix}randomanime*
Usage : ${prefix}randomanime
╰─⊱ *${prefix}animerandom*
Usage : ${prefix}animerandom
╰─⊱ *${prefix}ranime*
Usage : ${prefix}ranime
╰─⊱ *${prefix}waifu*
Usage : ${prefix}waifu
╰─⊱ *${prefix}waifu2*
Usage : ${prefix}waifu2
╰─⊱ *${prefix}waifu3*
Usage : ${prefix}waifu3
╰─⊱ *${prefix}nekonime*
Usage : ${prefix}nekonime
[Command yg dapat digunakan : ${prefix}nekonime, ${prefix}randomnekonime]
╰─⊱ *${prefix}scan* [upload gambar]
Usage : ${prefix}scan upload gambar screenshot anime yg ingin di scan [Pastikan gambar screenshotnya jelas ya!]
╰─⊱ *${prefix}pokemon*
Usage : ${prefix}pokemon

╔══✪〘 BUY VIP 〙✪═══════════
║➤${prefix}buyvip
║➤Deskripsi :gunakan command diatas untuk beli Full Akses Bot
╠════════════════════════════
✎═─⊱〘 BOT INDapk © 2021 〙⊰══`
}
exports.animemenu = animemenu