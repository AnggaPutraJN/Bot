const othermenu = (prefix) => { 
	return `
╔══✪〘 OTHER 〙✪══
║
╰─⊱ *${prefix}s [replay gambar]*
Usage : ${prefix}s Replay gambar atau masukin gambar
╰─⊱ *${prefix}toimg [replay sticker]*
Usage : ${prefix}toimg Replay Stickernya
╰─⊱ *${prefix}pokemon*
Usage : ${prefix}pokemon
╰─⊱ *${prefix}dadu*
Usage : ${prefix}dadu
╰─⊱ *${prefix}ocr [gambar]*
Usage : ${prefix}ocr [Masukin gambarnya]
╰─⊱ *${prefix}meme*
Usage : ${prefix}meme
╰─⊱ *${prefix}testime*
Usage : ${prefix}testime
╰─⊱ *${prefix}hobby*
Usage : ${prefix}hobby
╰─⊱ *${prefix}slap*
Usage : ${prefix}slap
╰─⊱ *${prefix}beritahoax*
Usage : ${prefix}beritahoax
╰─⊱ *${prefix}watak*
Usage : ${prefix}watak
╰─⊱ *${prefix}jsholat [daerah]*
Usage : ${prefix}jsholat [Masukin daerahnya]
╰─⊱ *${prefix}cekjodoh* [nama]
Usage : ${prefix}cekjodoh anggaputrajn [Masukin nama]
╰─⊱ *${prefix}artinama* [nama]
Usage : ${prefix}artinama anggaputrajn [Masukin nama]
╰─⊱ *${prefix}listsurah*
Usage : ${prefix}listsurah
╰─⊱ *${prefix}fitnah [@tag|pesan|balasanbot]*
Usage : ${prefix}fitnah Tag|Pesannya|Balasan botnya
║
╠═══✪〘 ANIME 〙✪══
║
╰─⊱ *${prefix}randomanime*
Usage : ${prefix}randomanime
╰─⊱ *${prefix}animerandom*
Usage : ${prefix}animerandom
╰─⊱ *${prefix}ranime*
Usage : ${prefix}ranime
╰─⊱ *${prefix}waifu*
Usage : ${prefix}waifu
╰─⊱ *${prefix}waifu2*
Usage : ${prefix}waifu2
╰─⊱ *${prefix}waifu3*
Usage : ${prefix}waifu3
╰─⊱ *${prefix}nekonime*
Usage : ${prefix}nekonime
╰─⊱ *${prefix}wait*
Usage : ${prefix}wait
╰─⊱ *${prefix}pokemon*
Usage : ${prefix}pokemon

║
╠═══✪〘 ANIMALS 〙✪══
║
╰─⊱ *${prefix}anjing*
Usage : ${prefix}anjing
║
╚═ Ketik *${prefix}kegunaanbot* untuk melihat list informasi tentang bot
   Ketik *${prefix}owner* untuk melihat kontak owner
   Mau donasi? 082286344446(Gopay)
   Jika tidak ingin donasi bantu Follow Ig aja kak 
   _instagram.com/indapk
║
╚═〘 BOT INDapk © 2021 〙`
}
exports.othermenu = othermenu