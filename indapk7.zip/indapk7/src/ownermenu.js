const ownermenu = (prefix) => { 
	return `
	
╔══✪〘 OWNER 〙✪══
║
╰─⊱ *${prefix}block 62858xxxxx*
╰─⊱ *${prefix}unblock 62858xxxxx*
╰─⊱ *${prefix}promote @tagmember*
╰─⊱ *${prefix}demote @tagadmin*
╰─⊱ *${prefix}leave*
╰─⊱  *${prefix}bc [Broadcast]*
╰─⊱  *${prefix}bc2 [Broadcast]*
╰─⊱  *${prefix}bc2 [Broadcast]*
╰─⊱  *${prefix}leave*
╰─⊱  *${prefix}clearall*
╰─⊱  *${prefix}clone*
╰─⊱  *${prefix}hidetag*
╰─⊱  *${prefix}hidetag2*
╰─⊱  *${prefix}setprefix*
╰─⊱  *${prefix}unban*
╰─⊱  *${prefix}ban*
╰─⊱ *${prefix}runtime*
╰─⊱ *${prefix}iklan*
╰─⊱ *${prefix}turnoff*
║
╚═〘 BOT INDapk 〙`
}
exports.ownermenu = ownermenu