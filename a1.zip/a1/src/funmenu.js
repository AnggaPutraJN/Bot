const funmenu = (prefix) => { 
	return `
✎═─⊱〘 𝐹𝑈𝑁 𝑀𝐸𝑁𝑈 〙⊰══
║
╰─⊱ *${prefix}vn [kode bhs] [teks]*
Usage : ${prefix}vn id Owner ganteng [Kode bahasa untuk bahasa Indonesia, Ketik ${prefix}kodebhs untuk cek kode-kode bahasanya]
╰─⊱ *${prefix}kodebhs*
Usage : ${prefix}kodebhs
╰─⊱ *${prefix}truth*
Usage : ${prefix}truth
╰─⊱ *${prefix}dare*
Usage : ${prefix}dare
╰─⊱ *${prefix}pinterest*
Usage : ${prefix}pinterest naruto (masukin aja text bebas)
╰─⊱ *${prefix}syg* [text]
Usage : ${prefix}syg aku ganteng gak [Masukkan text atau pertanyaan]

╔══✪〘 BUY VIP 〙✪═══════════
║➤${prefix}buyvip
║➤Deskripsi :gunakan command diatas untuk beli Full Akses Bot
╠════════════════════════════

✎═─⊱〘 BOT INDapk © 2021 〙⊰══`
}
exports.funmenu = funmenu