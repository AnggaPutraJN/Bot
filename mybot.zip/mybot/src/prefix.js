const cekprefix = (prefix) => { 
	return `
	Command YANG SAAT INI DIGUNAKAN *「* ${prefix} *」
	`
	}
exports.cekprefix = cekprefix