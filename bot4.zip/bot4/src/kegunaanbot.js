const kegunaanbot = () => { 
	return ` *👾INFO BOT👾*
	
╔════════✪〘 Fitur BOT 〙✪═══
╠➥ Mengubah gambar ke sticker
╠➥ Mengubah sticker ke gambar
╠➥ Download musik
╠➥ Download Game
╠➥ Gacha gambar anime
╠➥ Gacha gambar anime hentai
╠➥ Buka Nekopoi Tanpa VPN
╠➥ Fitur bermain sama bot
╠➥ Saran anime
╠➥ Kode-Kode Nuklir
╠➥ Cek Zodiak
╠➥ Membuat Nama Keren
╠➥ Coming soon
╠════════✪〘 TIPS DAN SYARAT BOT 〙✪═══
╠➥ Untuk menggunakan bot ini, harus daftar dulu sebagai user, dengan cara ketik command ${prefix}daftar Nama kamu | Umur kamu
╠➥ Untuk cek list botnya bisa ketik command : ${prefix}listmenu
╠➥ Jangan terlalu sering mengunakan bot (Spam bot), gunakan sewajarnya aja
╠➥ Jangan merespon bot saat melakukan broadcast atau promosikan game
╠➥ Laporkan ke owner bot jika ada error dengan cara ketik command ${prefix}owner
╠➥ Support Bot dengan cara ketik command ${prefix}donate
║
╚═〘 BOT INDapk © 2021 〙
`
}
exports.kegunaanbot = kegunaanbot
