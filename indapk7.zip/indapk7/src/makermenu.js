const makermenu = (prefix) => { 
	return `
╔══✪〘 MAKER 〙✪══
║
╰─⊱ *${prefix}shadow* [text]
║
╚═〘  BOT INDapk 〙`
}
exports.makermenu = makermenu