const gamingmenu = (prefix) => { 
	return `
╔══✪〘 GAMING ROOM 〙✪══════════
║
╠➥ *${prefix}menurom*
Usage : ${prefix}menurom
╠➥ *${prefix}gamemod*
Usage : ${prefix}gamemod
║
╠══✪〘 REQUEST GAME 〙✪══════════
╠➥ *${prefix}requestgame* [Nama Gamenya]
║Usage : ${prefix}requestgame
╠➥ *${prefix}requestgameemu* [Nama Gamenya]
║Usage : ${prefix}requestgameemu [Nama Gamenya], [Emulatornya]
║
╠═══════════════════════════
〘 BOT INDapk © 2021 〙

	`
}
exports.gamingmenu = gamingmenu