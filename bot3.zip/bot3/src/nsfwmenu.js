const nsfwmenu = (prefix) => { 
	return `
╔══✪〘 NSFW 〙✪══
║
║╰─⊱ *${prefix}randomhentai*
Usage : ${prefix}randomhentai
║╰─⊱ *${prefix}hentai*
Usage : ${prefix}hentai
║╰─⊱ *${prefix}nsfwblowjob*
Usage : ${prefix}nsfwblowjob
║╰─⊱ *${prefix}nsfwtrap*
Usage : ${prefix}nsfwtrap
║╰─⊱ *${prefix}kodenuklir2*
Usage : ${prefix}kodenuklir2
║╰─⊱ *${prefix}randomanime*
Usage : ${prefix}randomanime
║╰─⊱ *${prefix}cry*
Usage : ${prefix}cry
║╰─⊱ *${prefix}kiss*
Usage : ${prefix}kiss
║╰─⊱ *${prefix}randomhug*
Usage : ${prefix}randomhug
║╰─⊱ *${prefix}nekonime*
Usage : ${prefix}nekonime
║╰─⊱ *${prefix}waifu*
Usage : ${prefix}waifu
║╰─⊱ *${prefix}waifu2*
Usage : ${prefix}waifu2
║╰─⊱ *${prefix}kodenuklir*
Usage : ${prefix}kodenuklir
║╰─⊱ *${prefix}nekopoi*
Usage : ${prefix}nekopoi
║╰─⊱  *${prefix}indo(1-25)*
Usage : ${prefix}indo23 [Masukkan angkanya 1 sampai 25]
║
╚═〘 BOT INDapk © 2021 〙`
}
exports.nsfwmenu = nsfwmenu