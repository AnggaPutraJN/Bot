const caradaftar = () => { 
	return `
════✪〘 Tutorial Daftar 〙✪════
Silahkan Ketik command : *${prefix}d*Nama Kamu | Masukkan Umur
Contoh : *${prefix}d*AnggaPutraJN | 20

Jika sudah terdaftar, kalian sudah bisa mengakses botnya
Gunakan command : *${prefix}help*

Kalau mau mengakses semua fitur yg ada di bot, bisa langsung hubungi ownernya, atau pakai command dibawah ini
Gunakan command : *${prefix}buyvip*

╔════════════════════════
║➤ Report Bug : *${prefix}reportbug*
╠═══✪〘 OWNER 〙✪════
║➤ _wa.me/082286344446_ atau ketik command : *${prefix}owner*
║➤ Join Group 1 Owner : https://chat.whatsapp.com/Et6CVorLr5D3ILDkMlE6jW
║➤ Join Group 2 Owner : https://chat.whatsapp.com/GddnwqWKVzSLhrr9ikY9wE
║➤ Join Group 3 Owner : https://chat.whatsapp.com/G4P1tpV1MNd67efeMAEoof
╚➤〘 BOT INDapk © 2021 〙`
}
exports.caradaftar = caradaftar
