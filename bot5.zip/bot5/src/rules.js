const rules = (prefix) => { 
	return `
╔══✪〘 RULES BAGI PENGGUNA BOT 〙✪════
║
║➤ Tolong Gunakan Delay Jangan Spam Saat Menggunakan Bot.
║➤ Call/VC Bot Auto Block.
║➤ Jangan Call/VC Bot Kalau Tidak aktif.
║➤ Bot tidak aktif 24 jam, jadi tergantung kalau ownernya lagi ada waktu botnya juga on.
║➤ Jangan spam bot
║➤ Jangan telepon bot
║➤ Jangan mengeksploitasi bot
║
╠══✪〘 KONSEKUENSI BILA MELANGGAR RULES 〙✪════
║ *WARN/SOFT BLOCK*
║ *Bot Akan Memblokir Kamu Atau Keluar Dari Grup Yang Kamu Kelola*.
║ *PERMANENT BLOCK*
║ Rules ini untuk kenyamanan semua yang memakai bot ini 
║ Cek Kegunaan atau Fitur pada BOT silakan ketik *${prefix}kegunaanbot*
║ Jika sudah dipahami rules-nya, silakan ketik *${prefix}menu* untuk memulai!
║
╚═〘 BOT INDapk © 2021 〙

`
}
exports.rules = rules